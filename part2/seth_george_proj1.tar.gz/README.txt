I put all my prototypes into sndlib.h so that sndinfo and sndconv could easily call functions.
I implemented my functions in sndutil so that I could easily share function between sndinfo and sndconv.
 
 
sndconv:
Sound Conversion converts from CS229 file format AIFF, and vice versa.
The program reads in the name of the input file, and then read in the name of the output file
The output file should be written in the opposing file format.

sndinfo:
read first word of file
check if it is CS229 or FORM
if neither throw an error
otherwise parse the file according to the correct format

if CS229 parse each line and look for keywords
collect the values after each keyword disregarding lines starting with #
if a line doesn't start with # or a keywords, throw an error and exit
no keywords after start data
channels are read on the same line

if AIFF parse each the next 4 bytes to get remaining bytes in file
search for the COMM chunk and gather keyword information
search for the SSND chunk and gather it block information
parse the rest of the file